A package that connects to the BL-NET that is connected itself to a UVR1611 device by Technische Alternative. 

It is able to read digital and analog values as well as to set switches to ON/OFF/AUTO