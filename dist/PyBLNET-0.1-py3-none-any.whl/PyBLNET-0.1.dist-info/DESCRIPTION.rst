A package that connects to the BL-NET that is connected itself to a UVR1611 device by Technische Alternative. 


